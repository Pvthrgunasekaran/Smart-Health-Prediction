import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class HealthPredictServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        
        String symptoms = request.getParameter("symptoms").toLowerCase();
        String diagnosis = "Unable to predict. Please enter more specific symptoms.";

        if (symptoms.contains("fever") && symptoms.contains("cough")) {
            diagnosis = "Possible Flu or COVID-19";
        } else if (symptoms.contains("headache") && symptoms.contains("nausea")) {
            diagnosis = "Possible Migraine";
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>Prediction Result</h2>");
        out.println("<p><strong>Symptoms:</strong> " + symptoms + "</p>");
        out.println("<p><strong>Diagnosis:</strong> " + diagnosis + "</p>");
        out.println("<a href='index.html'>Go Back</a>");
        out.println("</body></html>");
    }
}
