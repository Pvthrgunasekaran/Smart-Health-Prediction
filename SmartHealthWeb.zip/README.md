# Smart Health Prediction System (Web Version)

This is a basic Java web application that predicts possible illnesses based on user-input symptoms.

## Technologies Used
- HTML/CSS for frontend
- Java Servlet for backend logic
- No database used

## How to Run
1. Import into an IDE like Eclipse as a Dynamic Web Project.
2. Configure and run on Apache Tomcat server.
3. Open `index.html`, enter symptoms, and get a prediction.

## Example Inputs
- `fever, cough` => Possible Flu or COVID-19
- `headache, nausea` => Possible Migraine
